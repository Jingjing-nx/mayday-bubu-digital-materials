# 卜卜 macOS 版

## 安装

1. 完整解压 `Mayday-Bubu-macOS-Universal-v1.0.3.zip`。
2. 双击 `安装卜卜-macOS.command`。
3. 如果出现“Apple 无法验证”提示，点“完成”，不要点“移到废纸篓”。
4. 双击 `安装被拦截-打开安全设置.webloc`，会直接打开“安全性与隐私”的“通用”页面。
5. 点击“仍要打开”或“Open Anyway”，输入 Mac 登录密码确认，再重新双击安装文件。
6. 重新打开 Codex；安装器会优先自动选中卜卜。

“仍要打开”按钮只会在尝试启动安装文件后出现，并会保留约一小时。
[查看 Apple 官方的允许步骤](https://support.apple.com/guide/mac-help/mh40616/mac)。

## 要求

- macOS 12.3+
- Apple 芯片或 Intel Mac
- 已安装并登录 Codex

## 功能

- 安装 Codex v2 宠物卜卜。
- 原生 AppKit 额度面板，约 30 ms 跟随卜卜并保持约 14 px 间距。
- Codex 额度每 5 分钟更新。
- BTC/USDT、ETH/USDT 每 5 秒更新。
- 不需要管理员权限或 API Key。

## 检查与卸载

- `检查卜卜-macOS.command`：检查宠物、Universal 2 架构、签名、启动项、额度和行情。
- `卸载卜卜-macOS.command`：只移除卜卜和本项目面板。
