---
name: bubu-desk-pet
description: Install, launch, diagnose, or remove the offline Bubu desktop pet on a Mac. Use when the user asks to add the bundled orange character, repair its local installation, show or hide it, check whether it can run, or remove it. The pet is self-contained and runs locally.
---

# Bubu Desk Pet

Use this skill to manage the bundled offline desktop pet.

## Safety rules

- Run `scripts/check_requirements.sh` before installation.
- Explain the write locations and request confirmation before installation or removal.
- Request confirmation before launching the pet because it opens a visible desktop window.
- Keep every action inside the bundled local desktop pet.
- Do not claim abilities that are not implemented by the bundled source.

## Check compatibility

Run:

```bash
bash scripts/check_requirements.sh
```

This check is read-only. It verifies the local operating system, compiler, free space, and bundled files.

## Install

Before running the installer, tell the user that it:

- builds the bundled source in a temporary directory;
- writes `~/Applications/卜卜桌宠.app`;
- moves an existing copy with the expected local identifier to the Trash;
- stops a running process named `BubuDeskPet` during replacement;
- opens the new copy after installation.

Then request confirmation. After confirmation, run:

```bash
bash scripts/install.sh --confirm-install
```

## Launch

After confirmation, run:

```bash
bash scripts/launch.sh --confirm-launch
```

## Diagnose

Run:

```bash
bash scripts/diagnose.sh
```

Diagnosis is read-only.

## Remove

Before removal, tell the user that the installed app will be moved to the Trash and its running process will be stopped. Then request confirmation and run:

```bash
bash scripts/uninstall.sh --confirm-uninstall
```

## Local interaction

- Click the pet to change its local phrase.
- Drag the pet to move it.
- Right-click for local display controls.
- Use the menu-bar item to show, hide, or quit the pet.

Read `references/permissions.md` for the exact local access boundaries.
