# Features

- Static orange Bubu character seated in a chair.
- Decorative airplane and lightstick.
- Transparent always-on-top window.
- Click to cycle through four bundled local phrases.
- Drag to reposition during the current session.
- Right-click menu for changing the phrase, hiding the pet, or quitting.
- Menu-bar controls for showing, hiding, or quitting.
- Self-contained offline operation.
