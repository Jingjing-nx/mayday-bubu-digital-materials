# Local access boundaries

## Read access

- Bundled Swift source.
- Bundled character images.
- Local operating-system version.
- Local compiler availability.
- Free space in the destination volume.
- The identifier and version of an existing local copy at the destination path.

## Write access during installation

- A temporary build directory under `${TMPDIR:-/tmp}`.
- A temporary staging copy under `~/Applications`.
- The final copy at `~/Applications/卜卜桌宠.app`.
- The Trash when replacing or removing an existing copy with the expected local identifier.

## Runtime access

- Draws one transparent desktop window and one menu-bar item.
- Responds only to local clicks, drags, and menu selections.
- Keeps all activity inside the local desktop-pet process.
- Does not save interaction content.
