import AppKit
import CoreGraphics
import Foundation

private let sceneSize = NSSize(width: 320, height: 310)
private let cellSize = NSSize(width: 192, height: 208)
private let petRect = NSRect(x: 64, y: 98, width: 192, height: 208)
private let bubbleRect = NSRect(x: 12, y: 10, width: 296, height: 70)
private let assetScale: CGFloat = 1.0362

private final class SpriteSheet {
    private let image: CGImage

    init(url: URL) throws {
        guard let source = NSImage(contentsOf: url),
              let cgImage = source.cgImage(forProposedRect: nil, context: nil, hints: nil)
        else {
            throw NSError(
                domain: "BubuDeskPet.SpriteSheet",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "无法读取桌宠图像"]
            )
        }
        guard cgImage.width == 1536, cgImage.height == 2288 else {
            throw NSError(
                domain: "BubuDeskPet.SpriteSheet",
                code: 2,
                userInfo: [NSLocalizedDescriptionKey: "桌宠图像尺寸不正确"]
            )
        }
        image = cgImage
    }

    func firstFrame() -> NSImage? {
        let crop = CGRect(x: 0, y: 0, width: 192, height: 208)
        guard let result = image.cropping(to: crop) else { return nil }
        return NSImage(cgImage: result, size: cellSize)
    }
}

private struct LocalAssets {
    let pet: NSImage
    let lightstick: NSImage
    let airplane: NSImage

    init(directory: URL) throws {
        let sheet = try SpriteSheet(
            url: directory.appendingPathComponent("spritesheet.webp")
        )
        guard let pet = sheet.firstFrame(),
              let lightstick = NSImage(
                  contentsOf: directory.appendingPathComponent("lightstick.png")
              ),
              let airplane = NSImage(
                  contentsOf: directory.appendingPathComponent("airplane.png")
              )
        else {
            throw NSError(
                domain: "BubuDeskPet.LocalAssets",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "缺少桌宠图像"]
            )
        }
        self.pet = pet
        self.lightstick = lightstick
        self.airplane = airplane
    }
}

private final class BubuPanel: NSPanel {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { false }
}

private final class BubuView: NSView {
    private let assets: LocalAssets
    private let phrases = [
        "今天也一起慢慢来。",
        "累了就歇一会儿。",
        "先完成眼前这一小步。",
        "做得很好，继续保持。",
    ]
    private var phraseIndex = 0
    private var dragStartScreenPoint: NSPoint?
    private var dragStartWindowOrigin: NSPoint?
    private var didDrag = false

    init(frame: NSRect, assets: LocalAssets) {
        self.assets = assets
        super.init(frame: frame)
        wantsLayer = true
    }

    required init?(coder: NSCoder) { nil }
    override var isFlipped: Bool { true }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        NSColor.clear.setFill()
        dirtyRect.fill()
        drawBubble()
        drawLightstick()
        drawPet()
        drawAirplane()
    }

    private func drawBubble() {
        let shadow = NSShadow()
        shadow.shadowColor = NSColor.black.withAlphaComponent(0.13)
        shadow.shadowBlurRadius = 8
        shadow.shadowOffset = NSSize(width: 0, height: 2)

        NSGraphicsContext.saveGraphicsState()
        shadow.set()
        let body = NSBezierPath(roundedRect: bubbleRect, xRadius: 18, yRadius: 18)
        NSColor(calibratedRed: 0.03, green: 0.66, blue: 0.62, alpha: 0.97).setFill()
        body.fill()
        let tail = NSBezierPath()
        tail.move(to: NSPoint(x: bubbleRect.midX - 10, y: bubbleRect.maxY - 1))
        tail.line(to: NSPoint(x: bubbleRect.midX + 10, y: bubbleRect.maxY - 1))
        tail.line(to: NSPoint(x: bubbleRect.midX, y: bubbleRect.maxY + 15))
        tail.close()
        tail.fill()
        NSGraphicsContext.restoreGraphicsState()

        let titleStyle = NSMutableParagraphStyle()
        titleStyle.lineBreakMode = .byTruncatingTail
        let bodyStyle = NSMutableParagraphStyle()
        bodyStyle.lineBreakMode = .byWordWrapping
        let titleAttributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 13.5, weight: .bold),
            .foregroundColor: NSColor.white,
            .paragraphStyle: titleStyle,
        ]
        let bodyAttributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: 13.5, weight: .semibold),
            .foregroundColor: NSColor.white,
            .paragraphStyle: bodyStyle,
        ]
        "●  卜卜桌宠".draw(
            in: NSRect(x: 28, y: 21, width: 264, height: 20),
            withAttributes: titleAttributes
        )
        phrases[phraseIndex].draw(
            in: NSRect(x: 28, y: 44, width: 264, height: 22),
            withAttributes: bodyAttributes
        )
    }

    private func drawPet() {
        assets.pet.draw(
            in: petRect,
            from: .zero,
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
    }

    private func drawLightstick() {
        let area = NSRect(
            x: petRect.midX - 91 * assetScale,
            y: petRect.minY + 104 * assetScale,
            width: 38 * assetScale,
            height: 102 * assetScale
        )
        let ratio = assets.lightstick.size.width / max(1, assets.lightstick.size.height)
        let height = 96 * assetScale
        let product = NSRect(
            x: area.minX + 8.4 * assetScale,
            y: area.minY + 3 * assetScale,
            width: height * ratio,
            height: height
        )
        NSGraphicsContext.saveGraphicsState()
        let transform = NSAffineTransform()
        transform.translateX(by: product.midX, yBy: product.midY)
        transform.rotate(byDegrees: 12)
        transform.translateX(by: -product.midX, yBy: -product.midY)
        transform.concat()
        assets.lightstick.draw(
            in: product,
            from: .zero,
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        NSGraphicsContext.restoreGraphicsState()
    }

    private func drawAirplane() {
        let rect = NSRect(
            x: petRect.midX - 130 * assetScale,
            y: petRect.minY + 40 * assetScale,
            width: 78 * assetScale,
            height: 65 * assetScale
        )
        assets.airplane.draw(
            in: rect,
            from: .zero,
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
    }

    override func mouseDown(with event: NSEvent) {
        dragStartScreenPoint = NSEvent.mouseLocation
        dragStartWindowOrigin = window?.frame.origin
        didDrag = false
    }

    override func mouseDragged(with event: NSEvent) {
        guard let startPoint = dragStartScreenPoint,
              let startOrigin = dragStartWindowOrigin,
              let window
        else { return }
        let current = NSEvent.mouseLocation
        let delta = NSPoint(x: current.x - startPoint.x, y: current.y - startPoint.y)
        if hypot(delta.x, delta.y) >= 3 { didDrag = true }
        window.setFrameOrigin(NSPoint(x: startOrigin.x + delta.x, y: startOrigin.y + delta.y))
    }

    override func mouseUp(with event: NSEvent) {
        defer {
            dragStartScreenPoint = nil
            dragStartWindowOrigin = nil
        }
        guard !didDrag else { return }
        phraseIndex = (phraseIndex + 1) % phrases.count
        needsDisplay = true
    }

    override func rightMouseDown(with event: NSEvent) {
        let menu = NSMenu(title: "卜卜桌宠")
        let next = NSMenuItem(title: "换一句话", action: #selector(nextPhrase), keyEquivalent: "")
        next.target = self
        menu.addItem(next)
        let hide = NSMenuItem(title: "隐藏桌宠", action: #selector(hidePet), keyEquivalent: "")
        hide.target = self
        menu.addItem(hide)
        menu.addItem(.separator())
        let quit = NSMenuItem(title: "退出桌宠", action: #selector(quitPet), keyEquivalent: "")
        quit.target = self
        menu.addItem(quit)
        NSMenu.popUpContextMenu(menu, with: event, for: self)
    }

    @objc private func nextPhrase() {
        phraseIndex = (phraseIndex + 1) % phrases.count
        needsDisplay = true
    }

    @objc private func hidePet() {
        window?.orderOut(nil)
    }

    @objc private func quitPet() {
        NSApp.terminate(nil)
    }
}

private final class AppDelegate: NSObject, NSApplicationDelegate {
    private var panel: BubuPanel?
    private var statusItem: NSStatusItem?

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        do {
            let resources = try resourceDirectory()
            let assets = try LocalAssets(directory: resources)
            makePanel(with: assets)
            makeStatusItem()
            showPet()
        } catch {
            let alert = NSAlert()
            alert.messageText = "卜卜桌宠无法打开"
            alert.informativeText = error.localizedDescription
            alert.runModal()
            NSApp.terminate(nil)
        }
    }

    func applicationShouldHandleReopen(
        _ sender: NSApplication,
        hasVisibleWindows flag: Bool
    ) -> Bool {
        showPet()
        return true
    }

    private func resourceDirectory() throws -> URL {
        guard let directory = Bundle.main.resourceURL else {
            throw NSError(
                domain: "BubuDeskPet.Resources",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "缺少桌宠资源"]
            )
        }
        return directory
    }

    private func makePanel(with assets: LocalAssets) {
        let panel = BubuPanel(
            contentRect: NSRect(origin: .zero, size: sceneSize),
            styleMask: [.borderless, .nonactivatingPanel],
            backing: .buffered,
            defer: false
        )
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = false
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.isMovableByWindowBackground = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.contentView = BubuView(
            frame: NSRect(origin: .zero, size: sceneSize),
            assets: assets
        )
        if let screen = NSScreen.main {
            let visible = screen.visibleFrame
            panel.setFrameOrigin(
                NSPoint(
                    x: visible.maxX - sceneSize.width - 24,
                    y: visible.minY + 36
                )
            )
        }
        self.panel = panel
    }

    private func makeStatusItem() {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        item.button?.title = "卜"
        item.button?.toolTip = "卜卜桌宠"
        let menu = NSMenu(title: "卜卜桌宠")
        let show = NSMenuItem(title: "显示桌宠", action: #selector(showPet), keyEquivalent: "")
        show.target = self
        menu.addItem(show)
        let hide = NSMenuItem(title: "隐藏桌宠", action: #selector(hidePet), keyEquivalent: "")
        hide.target = self
        menu.addItem(hide)
        menu.addItem(.separator())
        let quit = NSMenuItem(title: "退出桌宠", action: #selector(quitPet), keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)
        item.menu = menu
        statusItem = item
    }

    @objc private func showPet() {
        panel?.orderFrontRegardless()
    }

    @objc private func hidePet() {
        panel?.orderOut(nil)
    }

    @objc private func quitPet() {
        NSApp.terminate(nil)
    }
}

private func argumentValue(after name: String) -> String? {
    guard let index = CommandLine.arguments.firstIndex(of: name),
          CommandLine.arguments.indices.contains(index + 1)
    else { return nil }
    return CommandLine.arguments[index + 1]
}

private func runSelfTest() -> Never {
    guard let path = argumentValue(after: "--resources") else {
        print("{\"ok\":false,\"reason\":\"missing resources path\"}")
        exit(2)
    }
    do {
        _ = try LocalAssets(directory: URL(fileURLWithPath: path, isDirectory: true))
        print("{\"ok\":true,\"mode\":\"local\"}")
        exit(0)
    } catch {
        print("{\"ok\":false,\"reason\":\"invalid local assets\"}")
        exit(1)
    }
}

if CommandLine.arguments.contains("--self-test") {
    runSelfTest()
}

private let app = NSApplication.shared
private let delegate = AppDelegate()
app.delegate = delegate
app.run()
