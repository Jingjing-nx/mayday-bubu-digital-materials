#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ASSET_DIR="$SKILL_DIR/assets/resources"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This desktop pet requires a Mac."
  exit 1
fi

version="$(sw_vers -productVersion)"
major="${version%%.*}"
rest="${version#*.}"
minor="${rest%%.*}"
if (( major < 12 || (major == 12 && minor < 3) )); then
  echo "System version 12.3 or later is required."
  exit 1
fi

if ! command -v xcrun >/dev/null 2>&1 || ! xcrun --find swiftc >/dev/null 2>&1; then
  echo "A local Swift compiler is required."
  exit 1
fi

required=(
  "$SKILL_DIR/assets/main.swift"
  "$SKILL_DIR/assets/Info.plist"
  "$ASSET_DIR/spritesheet.webp"
  "$ASSET_DIR/lightstick.png"
  "$ASSET_DIR/airplane.png"
)
for path in "${required[@]}"; do
  if [[ ! -f "$path" ]]; then
    echo "Missing bundled file: $(basename "$path")"
    exit 1
  fi
done

verify_hash() {
  local path="$1"
  local expected="$2"
  local actual
  actual="$(shasum -a 256 "$path" | awk '{print $1}')"
  if [[ "$actual" != "$expected" ]]; then
    echo "Bundled file failed integrity check: $(basename "$path")"
    exit 1
  fi
}

verify_hash "$ASSET_DIR/spritesheet.webp" "9b179850352e7ff69040c55d5d0d87f06247e8651c465a0f2a13df9e97ff866d"
verify_hash "$ASSET_DIR/lightstick.png" "8348238e9ea5fdbd164aa9165b88f29dca03799cb89e09f64e0c0ac60dd756a3"
verify_hash "$ASSET_DIR/airplane.png" "13ab83761b7a7adad350fbc354266be05d15cb1c8fcccfdc9f52c49113e672c7"

destination_parent="$HOME/Applications"
probe_parent="$destination_parent"
if [[ ! -d "$probe_parent" ]]; then
  probe_parent="$HOME"
fi
available_kb="$(df -Pk "$probe_parent" | awk 'NR==2 {print $4}')"
if [[ -z "$available_kb" || "$available_kb" -lt 102400 ]]; then
  echo "At least 100 MB of free space is required."
  exit 1
fi

echo "Compatibility check passed."
echo "System: $version"
echo "Mode: offline and local only"
