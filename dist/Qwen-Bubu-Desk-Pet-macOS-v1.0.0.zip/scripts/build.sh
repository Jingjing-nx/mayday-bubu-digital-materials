#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="${1:-}"

if [[ -z "$OUTPUT_DIR" ]]; then
  echo "Usage: bash scripts/build.sh OUTPUT_DIRECTORY"
  exit 2
fi

bash "$SCRIPT_DIR/check_requirements.sh"

BUILD_ROOT="$(mktemp -d "${TMPDIR:-/tmp}/bubu-build.XXXXXX")"
cleanup() {
  if [[ -d "$BUILD_ROOT" ]]; then
    mv "$BUILD_ROOT" "${TMPDIR:-/tmp}/bubu-finished-$$"
  fi
}
trap cleanup EXIT

cp "$SKILL_DIR/assets/main.swift" "$BUILD_ROOT/main.swift"
APP_PATH="$BUILD_ROOT/卜卜桌宠.app"
mkdir -p "$APP_PATH/Contents/MacOS" "$APP_PATH/Contents/Resources"
cp "$SKILL_DIR/assets/Info.plist" "$APP_PATH/Contents/Info.plist"
cp "$SKILL_DIR/assets/resources/spritesheet.webp" "$APP_PATH/Contents/Resources/spritesheet.webp"
cp "$SKILL_DIR/assets/resources/lightstick.png" "$APP_PATH/Contents/Resources/lightstick.png"
cp "$SKILL_DIR/assets/resources/airplane.png" "$APP_PATH/Contents/Resources/airplane.png"

xcrun swiftc \
  -O \
  -framework AppKit \
  -framework CoreGraphics \
  "$BUILD_ROOT/main.swift" \
  -o "$APP_PATH/Contents/MacOS/BubuDeskPet"

chmod 755 "$APP_PATH/Contents/MacOS/BubuDeskPet"
codesign --force --sign - "$APP_PATH" >/dev/null
"$APP_PATH/Contents/MacOS/BubuDeskPet" \
  --self-test \
  --resources "$APP_PATH/Contents/Resources"

mkdir -p "$OUTPUT_DIR"
FINAL_PATH="$OUTPUT_DIR/卜卜桌宠.app"
if [[ -e "$FINAL_PATH" ]]; then
  echo "Output already exists: $FINAL_PATH"
  exit 1
fi
mv "$APP_PATH" "$FINAL_PATH"
echo "Built: $FINAL_PATH"
