#!/bin/bash
set -euo pipefail

if [[ "${1:-}" != "--confirm-install" ]]; then
  echo "Installation requires explicit confirmation."
  echo "Run: bash scripts/install.sh --confirm-install"
  exit 2
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEST_DIR="$HOME/Applications"
DEST_APP="$DEST_DIR/卜卜桌宠.app"
EXPECTED_ID="local.bubu.desk-pet"
STAGING_APP="$DEST_DIR/.bubu-stage-$$.app"
BACKUP_APP="$DEST_DIR/.bubu-backup-$$.app"
BUILD_OUTPUT="$(mktemp -d "${TMPDIR:-/tmp}/bubu-install.XXXXXX")"

cleanup() {
  if [[ -d "$STAGING_APP" ]]; then
    mv "$STAGING_APP" "${TMPDIR:-/tmp}/bubu-unused-stage-$$.app"
  fi
  if [[ -d "$BUILD_OUTPUT" ]]; then
    mv "$BUILD_OUTPUT" "${TMPDIR:-/tmp}/bubu-finished-install-$$"
  fi
}
trap cleanup EXIT

mkdir -p "$DEST_DIR"
bash "$SCRIPT_DIR/build.sh" "$BUILD_OUTPUT"
mv "$BUILD_OUTPUT/卜卜桌宠.app" "$STAGING_APP"

if [[ -d "$DEST_APP" ]]; then
  existing_id="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$DEST_APP/Contents/Info.plist" 2>/dev/null || true)"
  if [[ "$existing_id" != "$EXPECTED_ID" ]]; then
    echo "The destination contains an unrecognized copy. Installation stopped."
    exit 1
  fi
fi

pkill -x BubuDeskPet >/dev/null 2>&1 || true

if [[ -d "$DEST_APP" ]]; then
  mv "$DEST_APP" "$BACKUP_APP"
fi

if ! mv "$STAGING_APP" "$DEST_APP"; then
  if [[ -d "$BACKUP_APP" ]]; then
    mv "$BACKUP_APP" "$DEST_APP"
  fi
  echo "Installation failed."
  exit 1
fi

if [[ -d "$BACKUP_APP" ]]; then
  mkdir -p "$HOME/.Trash"
  stamp="$(date +%Y%m%d-%H%M%S)"
  mv "$BACKUP_APP" "$HOME/.Trash/卜卜桌宠-已替换-$stamp.app"
fi

open "$DEST_APP"
echo "Installed: $DEST_APP"
