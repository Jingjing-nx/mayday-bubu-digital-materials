#!/bin/bash
set -euo pipefail

if [[ "${1:-}" != "--confirm-launch" ]]; then
  echo "Launching requires explicit confirmation."
  echo "Run: bash scripts/launch.sh --confirm-launch"
  exit 2
fi

APP_PATH="$HOME/Applications/卜卜桌宠.app"
EXPECTED_ID="local.bubu.desk-pet"

if [[ ! -d "$APP_PATH" ]]; then
  echo "The desktop pet is not installed."
  exit 1
fi

actual_id="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/Contents/Info.plist" 2>/dev/null || true)"
if [[ "$actual_id" != "$EXPECTED_ID" ]]; then
  echo "The installed copy is not recognized."
  exit 1
fi

open "$APP_PATH"
echo "Launched: $APP_PATH"
