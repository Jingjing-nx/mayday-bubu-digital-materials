#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_PATH="$HOME/Applications/卜卜桌宠.app"
EXPECTED_ID="local.bubu.desk-pet"

bash "$SCRIPT_DIR/check_requirements.sh"

if [[ ! -d "$APP_PATH" ]]; then
  echo "Installed: no"
  exit 0
fi

actual_id="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/Contents/Info.plist" 2>/dev/null || true)"
if [[ "$actual_id" != "$EXPECTED_ID" ]]; then
  echo "Installed path contains an unrecognized copy."
  exit 1
fi

codesign --verify --deep --strict "$APP_PATH"
"$APP_PATH/Contents/MacOS/BubuDeskPet" \
  --self-test \
  --resources "$APP_PATH/Contents/Resources"

if pgrep -x BubuDeskPet >/dev/null 2>&1; then
  running="yes"
else
  running="no"
fi

echo "Installed: yes"
echo "Running: $running"
echo "Identifier: $actual_id"
