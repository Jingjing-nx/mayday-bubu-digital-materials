#!/bin/bash
set -euo pipefail

if [[ "${1:-}" != "--confirm-uninstall" ]]; then
  echo "Removal requires explicit confirmation."
  echo "Run: bash scripts/uninstall.sh --confirm-uninstall"
  exit 2
fi

APP_PATH="$HOME/Applications/卜卜桌宠.app"
EXPECTED_ID="local.bubu.desk-pet"

if [[ ! -d "$APP_PATH" ]]; then
  echo "The desktop pet is not installed."
  exit 0
fi

actual_id="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APP_PATH/Contents/Info.plist" 2>/dev/null || true)"
if [[ "$actual_id" != "$EXPECTED_ID" ]]; then
  echo "The installed copy is not recognized. Removal stopped."
  exit 1
fi

pkill -x BubuDeskPet >/dev/null 2>&1 || true
mkdir -p "$HOME/.Trash"
stamp="$(date +%Y%m%d-%H%M%S)"
mv "$APP_PATH" "$HOME/.Trash/卜卜桌宠-已移除-$stamp.app"
echo "Moved to Trash."
