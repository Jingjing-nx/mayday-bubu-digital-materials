﻿$ErrorActionPreference = 'Stop'

$skillRoot = Split-Path -Parent $PSScriptRoot
$assetRoot = Join-Path $skillRoot 'assets'
$resourceRoot = Join-Path $assetRoot 'resources'

if ($env:OS -ne 'Windows_NT') {
    throw 'This desktop pet requires Windows 10 or Windows 11.'
}

$build = [Environment]::OSVersion.Version.Build
if ($build -lt 17763) {
    throw 'Windows 10 version 1809 or later is required.'
}

try {
    Add-Type -AssemblyName PresentationFramework
    Add-Type -AssemblyName System.Windows.Forms
} catch {
    throw 'The required Windows desktop components are unavailable.'
}

$required = @(
    (Join-Path $assetRoot 'BubuDeskPet.ps1'),
    (Join-Path $assetRoot 'manifest.json'),
    (Join-Path $resourceRoot 'bubu.png'),
    (Join-Path $resourceRoot 'lightstick.png'),
    (Join-Path $resourceRoot 'airplane.png')
)
foreach ($path in $required) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing bundled file: $([IO.Path]::GetFileName($path))"
    }
}

$expected = [ordered]@{
    'bubu.png' = '0bed9a220f7e5102938fcd7f8f63cf05b64ca30dafe1c02d485e2a773ec88c3a'
    'lightstick.png' = '8348238e9ea5fdbd164aa9165b88f29dca03799cb89e09f64e0c0ac60dd756a3'
    'airplane.png' = '13ab83761b7a7adad350fbc354266be05d15cb1c8fcccfdc9f52c49113e672c7'
}
foreach ($entry in $expected.GetEnumerator()) {
    $path = Join-Path $resourceRoot $entry.Key
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $entry.Value) {
        throw "Bundled file failed integrity check: $($entry.Key)"
    }
}

$sourceText = Get-Content -LiteralPath (Join-Path $assetRoot 'BubuDeskPet.ps1') -Raw
$xamlMatch = [regex]::Match($sourceText, '(?s)\[xml\]\$xaml\s*=\s*@''(.*?)''@')
if (-not $xamlMatch.Success) {
    throw 'The bundled window definition is missing.'
}
try {
    $null = [xml]$xamlMatch.Groups[1].Value
} catch {
    throw 'The bundled window definition is invalid.'
}

$drive = Get-PSDrive -Name ([IO.Path]::GetPathRoot($env:LOCALAPPDATA).Substring(0, 1))
if ($drive.Free -lt 50MB) {
    throw 'At least 50 MB of free space is required.'
}

[ordered]@{
    ok = $true
    windowsBuild = $build
    mode = 'offline-local'
} | ConvertTo-Json -Compress
