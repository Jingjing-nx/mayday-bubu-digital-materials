﻿$ErrorActionPreference = 'Stop'

$skillRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'check_requirements.ps1') | Write-Output

$destination = Join-Path $env:LOCALAPPDATA 'BubuDeskPet'
$entry = Join-Path $destination 'BubuDeskPet.ps1'
$resourceRoot = Join-Path $destination 'resources'
$manifestPath = Join-Path $destination 'manifest.json'
$expectedId = 'local.bubu.desk-pet.windows'

if (-not (Test-Path -LiteralPath $destination)) {
    [ordered]@{ installed = $false } | ConvertTo-Json -Compress
    exit 0
}
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'The installed folder is not recognized.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.identifier -ne $expectedId) {
    throw 'The installed copy is not recognized.'
}

& powershell.exe -NoProfile -File $entry -SelfTest -ResourceDirectory $resourceRoot | Write-Output
[ordered]@{
    installed = $true
    version = $manifest.version
    destination = $destination
} | ConvertTo-Json -Compress
