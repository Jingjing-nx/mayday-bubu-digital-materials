﻿param([switch]$ConfirmInstall)

$ErrorActionPreference = 'Stop'
if (-not $ConfirmInstall) {
    throw 'Installation requires -ConfirmInstall.'
}

$skillRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot 'check_requirements.ps1') | Write-Output

$destination = Join-Path $env:LOCALAPPDATA 'BubuDeskPet'
$manifestPath = Join-Path $destination 'manifest.json'
$expectedId = 'local.bubu.desk-pet.windows'
$stopSignal = Join-Path $env:TEMP 'bubu-desk-pet.stop'
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$shortcutPath = Join-Path $startMenu 'Bubu Desk Pet.lnk'

if (Test-Path -LiteralPath $destination) {
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        throw 'The destination contains an unrecognized folder.'
    }
    $current = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    if ($current.identifier -ne $expectedId) {
        throw 'The destination contains an unrecognized copy.'
    }
    New-Item -ItemType File -Path $stopSignal -Force | Out-Null
    Start-Sleep -Milliseconds 900
    Remove-Item -LiteralPath $destination -Recurse -Force
}

New-Item -ItemType Directory -Path $destination -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $destination 'resources') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $skillRoot 'assets\BubuDeskPet.ps1') -Destination $destination
Copy-Item -LiteralPath (Join-Path $skillRoot 'assets\manifest.json') -Destination $destination
Copy-Item -LiteralPath (Join-Path $skillRoot 'assets\resources\bubu.png') -Destination (Join-Path $destination 'resources')
Copy-Item -LiteralPath (Join-Path $skillRoot 'assets\resources\lightstick.png') -Destination (Join-Path $destination 'resources')
Copy-Item -LiteralPath (Join-Path $skillRoot 'assets\resources\airplane.png') -Destination (Join-Path $destination 'resources')

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
$shortcut.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$(Join-Path $destination 'BubuDeskPet.ps1')`""
$shortcut.WorkingDirectory = $destination
$shortcut.Description = '卜卜桌宠'
$shortcut.Save()

& (Join-Path $PSScriptRoot 'launch.ps1') -ConfirmLaunch
Write-Output "Installed: $destination"
