﻿param([switch]$ConfirmLaunch)

$ErrorActionPreference = 'Stop'
if (-not $ConfirmLaunch) {
    throw 'Launching requires -ConfirmLaunch.'
}

$destination = Join-Path $env:LOCALAPPDATA 'BubuDeskPet'
$entry = Join-Path $destination 'BubuDeskPet.ps1'
$manifestPath = Join-Path $destination 'manifest.json'
$expectedId = 'local.bubu.desk-pet.windows'

if (-not (Test-Path -LiteralPath $entry -PathType Leaf) -or -not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'The desktop pet is not installed.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.identifier -ne $expectedId) {
    throw 'The installed copy is not recognized.'
}

$arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$entry`""
Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WorkingDirectory $destination
Write-Output "Launched: $entry"
