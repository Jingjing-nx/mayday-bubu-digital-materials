﻿param([switch]$ConfirmUninstall)

$ErrorActionPreference = 'Stop'
if (-not $ConfirmUninstall) {
    throw 'Removal requires -ConfirmUninstall.'
}

$destination = Join-Path $env:LOCALAPPDATA 'BubuDeskPet'
$manifestPath = Join-Path $destination 'manifest.json'
$expectedId = 'local.bubu.desk-pet.windows'
$shortcutPath = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Bubu Desk Pet.lnk'
$stopSignal = Join-Path $env:TEMP 'bubu-desk-pet.stop'

if (-not (Test-Path -LiteralPath $destination)) {
    Write-Output 'The desktop pet is not installed.'
    exit 0
}
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'The installed folder is not recognized. Removal stopped.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($manifest.identifier -ne $expectedId) {
    throw 'The installed copy is not recognized. Removal stopped.'
}

New-Item -ItemType File -Path $stopSignal -Force | Out-Null
Start-Sleep -Milliseconds 900
if (Test-Path -LiteralPath $shortcutPath) {
    Remove-Item -LiteralPath $shortcutPath -Force
}
Remove-Item -LiteralPath $destination -Recurse -Force
Write-Output 'Removed.'
