@echo off
setlocal
set "APP_DIR=%LOCALAPPDATA%\BubuDeskPet"
if not exist "%APP_DIR%\BubuDeskPet.ps1" (
  echo The desktop pet is not installed.
  pause
  exit /b 1
)
start "" "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%APP_DIR%\BubuDeskPet.ps1"
exit /b 0
