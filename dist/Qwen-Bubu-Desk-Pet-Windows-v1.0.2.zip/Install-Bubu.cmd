@echo off
setlocal
set "SKILL_DIR=%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SKILL_DIR%scripts\install.ps1" -ConfirmInstall
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" (
  echo Installation failed. Keep the error shown above.
) else (
  echo Installation completed.
)
pause
exit /b %EXIT_CODE%
