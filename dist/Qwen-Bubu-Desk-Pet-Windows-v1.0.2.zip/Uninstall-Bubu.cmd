@echo off
setlocal
set "SKILL_DIR=%~dp0"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%SKILL_DIR%scripts\uninstall.ps1" -ConfirmUninstall
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%EXIT_CODE%"=="0" (
  echo Removal failed. Keep the error shown above.
) else (
  echo Removal completed.
)
pause
exit /b %EXIT_CODE%
