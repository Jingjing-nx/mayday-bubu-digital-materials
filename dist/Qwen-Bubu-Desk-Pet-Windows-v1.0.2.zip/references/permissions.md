# Local access boundaries

## Read access

- Bundled PowerShell source and character images.
- Windows version and available desktop components.
- Free space on the local system drive.
- The local manifest at the installation destination.

## Write access during installation

- `%LOCALAPPDATA%\BubuDeskPet`.
- `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Bubu Desk Pet.lnk`.
- A local stop-signal file while replacing or removing a running copy.

## Runtime access

- Draws one transparent desktop window and one tray icon.
- Responds only to local clicks, drags, and menu selections.
- Keeps all activity inside the desktop-pet process.
- Does not save interaction content.
