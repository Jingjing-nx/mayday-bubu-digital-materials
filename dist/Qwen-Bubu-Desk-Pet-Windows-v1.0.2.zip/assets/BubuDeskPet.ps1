﻿param(
    [switch]$SelfTest,
    [string]$ResourceDirectory
)

$ErrorActionPreference = 'Stop'

function Get-ScriptRoot {
    if ($PSScriptRoot) { return $PSScriptRoot }
    return Split-Path -Parent $MyInvocation.MyCommand.Path
}

function Test-BubuAssets {
    param([string]$Root)
    $required = [ordered]@{
        'bubu.png' = '0bed9a220f7e5102938fcd7f8f63cf05b64ca30dafe1c02d485e2a773ec88c3a'
        'lightstick.png' = '8348238e9ea5fdbd164aa9165b88f29dca03799cb89e09f64e0c0ac60dd756a3'
        'airplane.png' = '13ab83761b7a7adad350fbc354266be05d15cb1c8fcccfdc9f52c49113e672c7'
    }
    foreach ($entry in $required.GetEnumerator()) {
        $name = $entry.Key
        $path = Join-Path $Root $name
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            throw "Missing local image: $name"
        }
        $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -ne $entry.Value) {
            throw "Invalid local image: $name"
        }
    }
}

$root = if ($ResourceDirectory) { $ResourceDirectory } else { Join-Path (Get-ScriptRoot) 'resources' }
Test-BubuAssets -Root $root

if ($SelfTest) {
    [ordered]@{ ok = $true; mode = 'local'; platform = 'windows' } | ConvertTo-Json -Compress
    exit 0
}

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Bubu Desk Pet"
        Width="320" Height="310"
        WindowStyle="None" AllowsTransparency="True"
        Background="Transparent" Topmost="True"
        ShowInTaskbar="False" ShowActivated="False"
        ResizeMode="NoResize" UseLayoutRounding="True" SnapsToDevicePixels="True">
  <Canvas Width="320" Height="310" Background="Transparent">
    <Border x:Name="Bubble" Canvas.Left="12" Canvas.Top="10" Width="296" Height="70"
            CornerRadius="18" Background="#F706A89F">
      <StackPanel Margin="16,10,16,8">
        <TextBlock Text="●  卜卜桌宠" Foreground="White" FontWeight="Bold" FontSize="14"/>
        <TextBlock x:Name="Phrase" Text="今天也一起慢慢来。" Foreground="White"
                   FontWeight="SemiBold" FontSize="14" Margin="0,5,0,0"/>
      </StackPanel>
    </Border>
    <Path Fill="#F706A89F" Data="M 150,79 L 170,79 L 160,94 Z"/>
    <Image x:Name="Airplane" Canvas.Left="42" Canvas.Top="135" Width="82" Height="68" Stretch="Uniform"/>
    <Image x:Name="Lightstick" Canvas.Left="70" Canvas.Top="180" Width="24" Height="126" Stretch="Uniform"/>
    <Image x:Name="Bubu" Canvas.Left="64" Canvas.Top="98" Width="192" Height="208" Stretch="Fill"/>
  </Canvas>
</Window>
'@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)
$phrase = $window.FindName('Phrase')
$bubu = $window.FindName('Bubu')
$lightstick = $window.FindName('Lightstick')
$airplane = $window.FindName('Airplane')

function New-BitmapImage {
    param([string]$Path)
    $bitmap = New-Object Windows.Media.Imaging.BitmapImage
    $bitmap.BeginInit()
    $bitmap.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bitmap.UriSource = [Uri]$Path
    $bitmap.EndInit()
    $bitmap.Freeze()
    return $bitmap
}

$bubu.Source = New-BitmapImage (Join-Path $root 'bubu.png')
$lightstick.Source = New-BitmapImage (Join-Path $root 'lightstick.png')
$airplane.Source = New-BitmapImage (Join-Path $root 'airplane.png')

$createdNew = $false
$mutex = [System.Threading.Mutex]::new($true, 'Local\BubuDeskPetWindow', [ref]$createdNew)
if (-not $createdNew) {
    exit 0
}

$phrases = @(
    '今天也一起慢慢来。',
    '累了就歇一会儿。',
    '先完成眼前这一小步。',
    '做得很好，继续保持。'
)
$script:phraseIndex = 0
$script:dragged = $false
$script:mouseStart = $null
$script:userHidden = $false
$script:closing = $false
$script:windowHandle = [IntPtr]::Zero

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class BubuWindowGuard {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SetWindowPos(
        IntPtr hWnd, IntPtr hWndInsertAfter,
        int x, int y, int width, int height, uint flags);
    public static readonly IntPtr Topmost = new IntPtr(-1);
    public const uint NoSize = 0x0001;
    public const uint NoMove = 0x0002;
    public const uint NoActivate = 0x0010;
    public const uint ShowWindow = 0x0040;
}
"@

$window.Add_SourceInitialized({
    $helper = New-Object System.Windows.Interop.WindowInteropHelper($window)
    $script:windowHandle = $helper.Handle
})

$keepPetVisible = {
    if ($script:userHidden -or $script:closing) { return }

    if (-not $window.IsVisible) {
        $window.Show()
    }
    if ($window.WindowState -eq [Windows.WindowState]::Minimized) {
        $window.WindowState = [Windows.WindowState]::Normal
    }

    $width = if ($window.ActualWidth -gt 0) { $window.ActualWidth } else { $window.Width }
    $height = if ($window.ActualHeight -gt 0) { $window.ActualHeight } else { $window.Height }
    $leftLimit = [Windows.SystemParameters]::VirtualScreenLeft
    $topLimit = [Windows.SystemParameters]::VirtualScreenTop
    $rightLimit = $leftLimit + [Windows.SystemParameters]::VirtualScreenWidth - $width
    $bottomLimit = $topLimit + [Windows.SystemParameters]::VirtualScreenHeight - $height
    if ($window.Left -lt $leftLimit) { $window.Left = $leftLimit }
    if ($window.Top -lt $topLimit) { $window.Top = $topLimit }
    if ($window.Left -gt $rightLimit) { $window.Left = $rightLimit }
    if ($window.Top -gt $bottomLimit) { $window.Top = $bottomLimit }

    if ($script:windowHandle -ne [IntPtr]::Zero) {
        $flags = [BubuWindowGuard]::NoSize -bor
                 [BubuWindowGuard]::NoMove -bor
                 [BubuWindowGuard]::NoActivate -bor
                 [BubuWindowGuard]::ShowWindow
        [BubuWindowGuard]::SetWindowPos(
            $script:windowHandle,
            [BubuWindowGuard]::Topmost,
            0, 0, 0, 0,
            $flags
        ) | Out-Null
    }
}

$nextPhrase = {
    $script:phraseIndex = ($script:phraseIndex + 1) % $phrases.Count
    $phrase.Text = $phrases[$script:phraseIndex]
}

$window.Add_MouseLeftButtonDown({
    param($sender, $event)
    $script:dragged = $false
    $script:mouseStart = $event.GetPosition($window)
    $window.CaptureMouse()
})

$window.Add_MouseMove({
    param($sender, $event)
    if ($event.LeftButton -ne [Windows.Input.MouseButtonState]::Pressed -or -not $script:mouseStart) { return }
    $current = $event.GetPosition($window)
    if (-not $script:dragged -and
        ([Math]::Abs($current.X - $script:mouseStart.X) -gt 4 -or
         [Math]::Abs($current.Y - $script:mouseStart.Y) -gt 4)) {
        $script:dragged = $true
        $window.ReleaseMouseCapture()
        try {
            $window.DragMove()
        } catch {
            # The pointer may be released between the movement check and DragMove.
        }
    }
})

$window.Add_MouseLeftButtonUp({
    $window.ReleaseMouseCapture()
    if (-not $script:dragged) { & $nextPhrase }
    $script:mouseStart = $null
})

$contextMenu = New-Object Windows.Controls.ContextMenu
$nextItem = New-Object Windows.Controls.MenuItem
$nextItem.Header = '换一句话'
$nextItem.Add_Click($nextPhrase)
$contextMenu.Items.Add($nextItem) | Out-Null
$hideItem = New-Object Windows.Controls.MenuItem
$hideItem.Header = '隐藏桌宠'
$hideItem.Add_Click({ $script:userHidden = $true; $window.Hide() })
$contextMenu.Items.Add($hideItem) | Out-Null
$contextMenu.Items.Add((New-Object Windows.Controls.Separator)) | Out-Null
$quitItem = New-Object Windows.Controls.MenuItem
$quitItem.Header = '退出桌宠'
$quitItem.Add_Click({ $script:closing = $true; $window.Close() })
$contextMenu.Items.Add($quitItem) | Out-Null
$window.ContextMenu = $contextMenu

$tray = New-Object System.Windows.Forms.NotifyIcon
$tray.Text = '卜卜桌宠'
$tray.Icon = [System.Drawing.SystemIcons]::Information
$tray.Visible = $true
$trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
$showTray = $trayMenu.Items.Add('显示桌宠')
$showTray.Add_Click({ $script:userHidden = $false; & $keepPetVisible })
$hideTray = $trayMenu.Items.Add('隐藏桌宠')
$hideTray.Add_Click({ $script:userHidden = $true; $window.Hide() })
$trayMenu.Items.Add('-') | Out-Null
$quitTray = $trayMenu.Items.Add('退出桌宠')
$quitTray.Add_Click({ $script:closing = $true; $window.Close() })
$tray.ContextMenuStrip = $trayMenu
$tray.Add_DoubleClick({ $script:userHidden = $false; & $keepPetVisible })

$workArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$window.Left = $workArea.Right - $window.Width - 24
$window.Top = $workArea.Bottom - $window.Height - 36

$stopSignal = Join-Path $env:TEMP 'bubu-desk-pet.stop'
if (Test-Path -LiteralPath $stopSignal) { Remove-Item -LiteralPath $stopSignal -Force }
$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(750)
$timer.Add_Tick({
    if (Test-Path -LiteralPath $stopSignal) {
        Remove-Item -LiteralPath $stopSignal -Force -ErrorAction SilentlyContinue
        $script:closing = $true
        $window.Close()
        return
    }
    & $keepPetVisible
})
$timer.Start()

$window.Add_Closed({
    $timer.Stop()
    $tray.Visible = $false
    $tray.Dispose()
    $mutex.ReleaseMutex()
    $mutex.Dispose()
    [Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown()
})

$window.Show()
& $keepPetVisible
[Windows.Threading.Dispatcher]::Run()
