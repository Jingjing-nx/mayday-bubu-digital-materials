---
name: bubu-desk-pet-windows
description: Install, launch, diagnose, or remove the offline Bubu desktop pet on Windows 10 or Windows 11. Use when the user asks for the Windows edition of the bundled orange desktop character, wants to check compatibility, install it, show or hide it, repair it, or remove it. The pet is self-contained and runs locally.
---

# Bubu Desk Pet for Windows

Manage the bundled offline desktop pet.

## Safety rules

- Run `scripts/check_requirements.ps1` before installation.
- Explain the write locations and request confirmation before installation or removal.
- Request confirmation before launching because it opens a visible desktop window and tray icon.
- Keep every action inside the bundled local desktop pet.
- Do not claim abilities that are not implemented by the bundled source.

## Check compatibility

Run in PowerShell:

```powershell
powershell.exe -NoProfile -File scripts\check_requirements.ps1
```

This read-only check verifies Windows version, desktop components, free space, and bundled files.

## Install

Before installation, tell the user that the installer:

- writes `%LOCALAPPDATA%\BubuDeskPet`;
- replaces only a copy carrying the expected local manifest;
- adds a shortcut under the current user's Start menu;
- launches the new copy after installation.

Then request confirmation and run:

```powershell
powershell.exe -NoProfile -File scripts\install.ps1 -ConfirmInstall
```

For manual use, the user can also double-click `Install-Bubu.cmd` after extracting the archive.

## Launch

After confirmation, run:

```powershell
powershell.exe -NoProfile -File scripts\launch.ps1 -ConfirmLaunch
```

## Diagnose

Run:

```powershell
powershell.exe -NoProfile -File scripts\diagnose.ps1
```

Diagnosis is read-only.

## Remove

Before removal, explain that the installed folder and Start-menu shortcut will be removed. Then request confirmation and run:

```powershell
powershell.exe -NoProfile -File scripts\uninstall.ps1 -ConfirmUninstall
```

## Local interaction

- Click the pet to change its local phrase.
- Drag the pet to move it.
- Right-click the pet for local display controls.
- Use the tray icon to show, hide, or quit the pet.

Read `references/permissions.md` for exact local access boundaries.
